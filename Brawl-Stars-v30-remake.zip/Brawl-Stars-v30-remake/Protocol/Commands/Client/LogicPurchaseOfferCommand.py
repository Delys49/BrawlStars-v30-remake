from ByteStream.Reader import Reader
from Logic.Home.LogicShopData import LogicShopData
from Protocol.Messages.Server.AvailableServerCommandMessage import AvailableServerCommandMessage
from Protocol.Messages.Server.LoginFailedMessage import LoginFailedMessage

class LogicPurchaseOfferCommand(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.readVInt()
        self.readVInt()
        self.readLogicLong()

        self.offer_index = self.readVInt()

        self.brawler = self.readDataReference()[1]

    def process(self, db):
        offer_id       = LogicShopData.offers[self.offer_index]['OfferID']
        offer_resource = LogicShopData.offers[self.offer_index]['ShopType']
        offer_cost     = LogicShopData.offers[self.offer_index]['Cost']
        offer_amount   = LogicShopData.offers[self.offer_index]['Multiplier']
        offer_char = LogicShopData.offers[self.offer_index]['DataReference'][1]
        offer_metadata = LogicShopData.offers[self.offer_index]['FullAkk']
        giveID = LogicShopData.offers[self.offer_index]['ID']
        
        if offer_metadata == 'Full' and giveID==0:
            self.player.brawlers_unlocked = self.player.brawlers_id
            db.update_player_account(self.player.token, 'UnlockedBrawlers', self.player.brawlers_unlocked)
            LoginFailedMessage(self.client, self.player, f'All brawlers unlocked!').send()
            return
        	   
        	   		
        if not LogicShopData.offers[self.offer_index]['Claimed']:


            self.player.delivery_items = {
                'Count': 1,
                'Type': 0,
                'Items': []
            }

            if giveID==1:
                pass

            elif giveID==2:
                pass

            elif giveID==3:
                pass

            elif giveID==4:
                item = {'Amount': 1, 'DataRef': [16, 1 ], 'Skin': [0, 0], 'Pin': [0, 0], 'Value':1 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                if 1 not in self.player.brawlers_unlocked:
                    self.player.brawlers_unlocked.append(1)
                    db.update_player_account(self.player.token, 'UnlockedBrawlers', self.player.brawlers_unlocked)
                    
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [29, 217], 'Pin': [0, 0], 'Value':9 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.unlocked_skins.append(217)
                db.update_player_account(self.player.token, 'UnlockedSkins', self.player.unlocked_skins)
                LogicShopData.offers[self.offer_index]['Claimed'] = True

            elif giveID==5:
                item = {'Amount': 1, 'DataRef': [16, 39], 'Skin': [0, 0], 'Pin': [0, 0], 'Value':1 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                if 39 not in self.player.brawlers_unlocked:
                    self.player.brawlers_unlocked.append(39)
                    db.update_player_account(self.player.token, 'UnlockedBrawlers', self.player.brawlers_unlocked)
                LogicShopData.offers[self.offer_index]['Claimed'] = True
                item = {'Amount': 1228, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [0, 0], 'Value':7 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.resources[1]['Amount'] = self.player.resources[1]['Amount'] + 1288
                db.update_player_account(self.player.token, 'Resources', self.player.resources)
                
                item = {'Amount': 900, 'DataRef': [16, 39 ], 'Skin': [0, 0], 'Pin': [0, 0], 'Value':6 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)

                self.player.brawlers_powerpoints[str(39)] = self.player.brawlers_powerpoints[str(39)] + 900
                db.update_player_account(self.player.token, 'BrawlersPowerPoints', self.player.brawlers_powerpoints)
                
                
            elif giveID==6:
                item = {'Amount': 100, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [0, 0], 'Value':7 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.resources[1]['Amount'] = self.player.resources[1]['Amount'] + 100
                db.update_player_account(self.player.token, 'Resources', self.player.resources)
                
                
            elif giveID==7: #336-343
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [29, 215], 'Pin': [0, 0], 'Value':9 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.unlocked_skins.append(215)
                db.update_player_account(self.player.token, 'UnlockedSkins', self.player.unlocked_skins)
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [52, 336], 'Value':11 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.emotes_id.append(336)
                db.update_player_account(self.player.token, 'UnlockedPins', self.player.emotes_id)
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [52, 337], 'Value':11 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.emotes_id.append(337)
                db.update_player_account(self.player.token, 'UnlockedPins', self.player.emotes_id)
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [52, 338], 'Value':11 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.emotes_id.append(338)
                db.update_player_account(self.player.token, 'UnlockedPins', self.player.emotes_id)
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [52, 339], 'Value':11 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.emotes_id.append(339)
                db.update_player_account(self.player.token, 'UnlockedPins', self.player.emotes_id)
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [52, 340], 'Value':11 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.emotes_id.append(340)
                db.update_player_account(self.player.token, 'UnlockedPins', self.player.emotes_id)
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [52, 341], 'Value':11 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.emotes_id.append(341)
                db.update_player_account(self.player.token, 'UnlockedPins', self.player.emotes_id)
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [52, 342], 'Value':11 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.emotes_id.append(342)
                db.update_player_account(self.player.token, 'UnlockedPins', self.player.emotes_id)
                item = {'Amount': 1, 'DataRef': [0, 0], 'Skin': [0, 0], 'Pin': [52, 343], 'Value':11 }
                self.player.delivery_items['Type'] = 100
                self.player.delivery_items['Items'].append(item)
                self.player.emotes_id.append(434)
                db.update_player_account(self.player.token, 'UnlockedPins', self.player.emotes_id)
                LogicShopData.offers[self.offer_index]['Claimed'] = True
                




            #if offer_id == 1:
            #    item = {'Amount': offer_amount, 'DataRef': [0, 0], 'Value':7 }
            #    self.player.delivery_items['Type'] = 100
            #    self.player.delivery_items['Items'].append(item)

#                self.player.resources[1]['Amount'] = self.player.resources[1]['Amount'] + offer_amount
 #               db.update_player_account(self.player.token, 'Resources', self.player.resources)
  #              LogicShopData.offers[self.offer_index]['Claimed'] = True
#
#
 #           elif offer_id == 16:
  #              item = {'Amount': offer_amount, 'DataRef': [0, 0], 'Value':8 }
   #             self.player.delivery_items['Type'] = 100
    #            self.player.delivery_items['Items'].append(item)
#
 #               self.player.gems = self.player.gems + offer_amount
  #              db.update_player_account(self.player.token, 'Gems', self.player.gems)
   #             LogicShopData.offers[self.offer_index]['Claimed'] = True
##           elif offer_id == 9:
  #              item = {'Amount': offer_amount, 'DataRef': [0, 0], 'Value':2 }
   #             self.player.delivery_items['Type'] = 100
    #            self.player.delivery_items['Items'].append(item)
#
 #               self.player.token_doubler = self.player.token_doubler + offer_amount
  #              db.update_player_account(self.player.token, 'TokenDoubler', self.player.token_doubler)
   #             LogicShopData.offers[self.offer_index]['Claimed'] = True
#
 #           elif offer_id == 3:
  #              item = {'Amount': offer_amount, 'DataRef': [16, offer_char ], 'Value':1 }
   #             self.player.delivery_items['Type'] = 100
    #            self.player.delivery_items['Items'].append(item)
     #           if offer_char not in self.player.brawlers_unlocked:
      #              self.player.brawlers_unlocked.append(offer_char)
       #             db.update_player_account(self.player.token, 'UnlockedBrawlers', self.player.brawlers_unlocked)
        #        LogicShopData.offers[self.offer_index]['Claimed'] = True
#
 #           elif offer_id == 12:
  #              item = {'Amount': offer_amount, 'DataRef': [16, self.brawler ], 'Value':6 }
   #             self.player.delivery_items['Type'] = 100
    #            self.player.delivery_items['Items'].append(item)
#
 #               self.player.brawlers_powerpoints[str(self.brawler)] = self.player.brawlers_powerpoints[str(self.brawler)] + offer_amount
  #              db.update_player_account(self.player.token, 'BrawlersPowerPoints', self.player.brawlers_powerpoints)
   #             LogicShopData.offers[self.offer_index]['Claimed'] = True
#
#
 #           elif offer_id == 8:
  #              item = {'Amount': offer_amount, 'DataRef': [16, offer_char ], 'Value':6 }
   #             self.player.delivery_items['Type'] = 100
    #            self.player.delivery_items['Items'].append(item)
#
 #               self.player.brawlers_powerpoints[str(offer_char)] = self.player.brawlers_powerpoints[str(offer_char)] + offer_amount
  #              db.update_player_account(self.player.token, 'BrawlersPowerPoints', self.player.brawlers_powerpoints)
   #             LogicShopData.offers[self.offer_index]['Claimed'] = True
#
 #           elif offer_id in [0, 6]:
  #              self.player.delivery_items['Type'] = 10
   #             self.player.delivery_items['Count'] = offer_amount
    #            LogicShopData.offers[self.offer_index]['Claimed'] = True
#
#
 #           elif offer_id == 14:
  #              self.player.delivery_items['Type'] = 12
   #             self.player.delivery_items['Count'] = offer_amount
    #            LogicShopData.offers[self.offer_index]['Claimed'] = True
#
#
 #           elif offer_id == 10:
  #              self.player.delivery_items['Type'] = 11
   #             self.player.delivery_items['Count'] = offer_amount
    #            LogicShopData.offers[self.offer_index]['Claimed'] = True
#
 #           else:
  #              print(f"Unsupported offer ID: {offer_id}")


            if offer_resource == 0:
                self.player.gems = self.player.gems - offer_cost
                db.update_player_account(self.player.token, 'Gems', self.player.gems)

            elif offer_resource == 1:
                self.player.resources[1]['Amount'] = self.player.resources[1]['Amount'] - offer_cost
                db.update_player_account(self.player.token, 'Resources', self.player.resources)

            elif offer_resource == 3:
                self.player.resources[3]['Amount'] = self.player.resources[3]['Amount'] - offer_cost
                db.update_player_account(self.player.token, 'Resources', self.player.resources)

            self.player.db = db

            AvailableServerCommandMessage(self.client, self.player, 203, {}).send()



